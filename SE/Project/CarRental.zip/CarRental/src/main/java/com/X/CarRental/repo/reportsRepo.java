package com.X.CarRental.repo;

import com.X.CarRental.model.report;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Getter
@Repository
public class reportsRepo {

    private String url = "jdbc:sqlserver://localhost:1433;databaseName=xCarRental;encrypt=false";
    private String username = "sa";
    private String password = "Y2S1seProject";
    private Connection connection;
    ObjectMapper mapper = new ObjectMapper();
    ArrayList<report> reports = new ArrayList<>();

    public reportsRepo(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            System.out.println("Driver loaded!");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver failed!" + e.getMessage());
        }

        try{
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection successful!");
        } catch (SQLException e) {
            System.out.println("Connection failed!" + e.getMessage());
        }
    }

    public ArrayList<String> setParameters(String parameters) {
        String[] parts = parameters.split(",");

        ArrayList<String> params = new ArrayList<>();
        for (String p : parts) {
            params.add(p.trim());
        }

        return params;
    }

    public void redoReports(){
        reports.clear();
        String query = "SELECT * FROM Reports";
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                report r = new report(
                        rs.getInt("rid"),
                        rs.getString("name"),
                        rs.getDate("createDate").toLocalDate(),
                        rs.getTimestamp("startDate"),
                        rs.getTimestamp("endDate"),
                        setParameters(rs.getString("parameters")),
                        setParametersAnswers(setParameters(rs.getString("parameters")), rs.getTimestamp("startDate").toLocalDateTime(), rs.getTimestamp("endDate").toLocalDateTime()),
                        rs.getString("reportType")
                );
                reports.add(r);
            }
        } catch (SQLException e) {
            System.out.println("SQL error at redoReports: " + e.getMessage());
        }
    }

    public report getReport(int rid) {
        redoReports();
        for (report r : reports) {
            if (r.getRid() == rid) {
                return r;
            }
        }
        return null;
    }

    public List<Map<String, Object>> getBookings() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Bookings");

            List<Map<String, Object>> list = new ArrayList<>();
            ResultSetMetaData md = rs.getMetaData();
            int columns = md.getColumnCount();

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                for (int i = 1; i <= columns; i++) {
                    row.put(md.getColumnLabel(i), rs.getObject(i)); // key = column name, value = cell
                }
                list.add(row);
            }
            return list;
        } catch (SQLException e){
            System.out.println("SQL error: " + e.getMessage());
        }
        return null;
    }

    public List<Map<String, Object>> getBetweenDatesBookings(LocalDateTime startDate, LocalDateTime endDate){
        List<Map<String, Object>> bookings = new ArrayList<>();

        String query = "SELECT * FROM Bookings WHERE JSON_VALUE(pickup, '$.time') >= ? AND JSON_VALUE(dropoff, '$.time') <= ?";


        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setTimestamp(1, Timestamp.valueOf(startDate));
            stmt.setTimestamp(2, Timestamp.valueOf(endDate));

            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData md = rs.getMetaData();

            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("id", rs.getObject("id"));
                row.put("totalFee", rs.getObject("totalFee"));
                row.put("Status", rs.getObject("currentStatus"));
                row.put("driverID", rs.getObject("driverID"));
                row.put("carVIN", rs.getObject("carVIN"));
                row.put("buyerNIC", rs.getObject("buyerNIC"));

                String pickupJson = rs.getString("pickup");
                String dropoffJson = rs.getString("dropoff");

                Map<String, String> pickup = mapper.readValue(pickupJson, Map.class);
                Map dropoff = mapper.readValue(dropoffJson, Map.class);

                row.put("pickup time", pickup.get("time"));
                row.put("pickup location", pickup.get("location"));
                row.put("dropoff time", dropoff.get("time"));
                row.put("dropoff location", dropoff.get("location"));

                bookings.add(row);
            }

        } catch (SQLException e) {
            System.out.println("SQL error: " + e.getMessage());
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        return bookings;
    }

    /*Parameter Answer Stuff*/

    public ArrayList<String> setParametersAnswers(ArrayList<String> parameters, LocalDateTime startTime, LocalDateTime endTime) throws SQLException {
        ArrayList<String> answers = new ArrayList<>();
        for (int i = 0; i < parameters.size(); i++) {
            switch (parameters.get(i)){
                case "Total Income":
                    answers.add(getTotalIncome(startTime, endTime));
                    break;
                case "Total Bookings":
                    answers.add(getTotalBookings(startTime, endTime));
                    break;
                case "Most used cars":
                    answers.add(mostUsedCars(startTime, endTime));
                    break;
                case "Least used cars":
                    answers.add(leastUsedCars(startTime, endTime));
                    break;
                case "Cancellations":
                    answers.add(cancellations(startTime, endTime));
                    break;
                default:
                    answers.add("Null");
            }
        }
        return answers;
    }

    public String getTotalIncome(LocalDateTime startDate, LocalDateTime endDate) throws SQLException {
        String query = "SELECT SUM(totalFee) FROM Bookings WHERE currentStatus != 'Cancelled' AND JSON_VALUE(pickup, '$.time') >= ? AND JSON_VALUE(dropoff, '$.time') <= ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setTimestamp(1, Timestamp.valueOf(startDate));
            stmt.setTimestamp(2, Timestamp.valueOf(endDate));
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // if SUM returns null (no rows), handle it
                return rs.getString(1) != null ? rs.getString(1) : "0";
            }
        }
        return "0";
    }

    public String getTotalBookings(LocalDateTime startDate, LocalDateTime endDate) throws SQLException {
        String query = "SELECT COUNT(*) FROM Bookings WHERE currentStatus != 'Cancelled' AND JSON_VALUE(pickup, '$.time') >= ? AND JSON_VALUE(dropoff, '$.time') <= ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setTimestamp(1, Timestamp.valueOf(startDate));
            stmt.setTimestamp(2, Timestamp.valueOf(endDate));
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return Integer.toString(rs.getInt(1));
            }
        }
        return "0";
    }

    public String mostUsedCars(LocalDateTime startDate, LocalDateTime endDate) throws SQLException {
        ArrayList<String> list = new ArrayList<>();
        String query = "SELECT TOP 3 c.carType FROM Car c JOIN Bookings b ON b.carVIN = c.vin WHERE JSON_VALUE(b.pickup, '$.time') >= ? AND JSON_VALUE(b.dropoff, '$.time') <= ? AND b.currentStatus != 'Cancelled' GROUP BY c.carType ORDER BY COUNT(b.id) DESC";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setTimestamp(1, Timestamp.valueOf(startDate));
        stmt.setTimestamp(2, Timestamp.valueOf(endDate));
        ResultSet rs = stmt.executeQuery();
        while(rs.next()){
            list.add(rs.getString("carType"));
        }
        return (list.toString() == "[]") ? "Null" : list.toString();
    }

    public String leastUsedCars(LocalDateTime startDate, LocalDateTime endDate) throws SQLException {
        ArrayList<String> list = new ArrayList<>();
        String query = "SELECT TOP 3 c.carType FROM Car c JOIN Bookings b ON b.carVIN = c.vin WHERE JSON_VALUE(b.pickup, '$.time') >= ? AND JSON_VALUE(b.dropoff, '$.time') <= ? AND b.currentStatus != 'Cancelled' GROUP BY c.carType ORDER BY COUNT(b.id) ASC";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setTimestamp(1, Timestamp.valueOf(startDate));
        stmt.setTimestamp(2, Timestamp.valueOf(endDate));
        ResultSet rs = stmt.executeQuery();
        while(rs.next()){
            list.add(rs.getString("carType"));
        }
        return (Objects.equals(list.toString(), "[]")) ? "Null" : list.toString();
    }

    public String cancellations(LocalDateTime startDate, LocalDateTime endDate) throws SQLException {
        String query = "SELECT COUNT(*) FROM Bookings WHERE currentStatus = 'Cancelled' AND JSON_VALUE(pickup, '$.time') >= ? AND JSON_VALUE(dropoff, '$.time') <= ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setTimestamp(1, Timestamp.valueOf(startDate));
            stmt.setTimestamp(2, Timestamp.valueOf(endDate));
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return Integer.toString(rs.getInt(1));
            }
        }
        return "0";
    }

    /*Create Report */
    public void createReport(String name, LocalDateTime startDate, LocalDateTime endDate, String parameters, String reportType, LocalDate createDate) {
        String query = "INSERT INTO Reports (name, startDate, endDate, parameters, reportType, createDate) VALUES (?, ?, ?, ?, ?, ?)";
        try(PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setTimestamp(2, Timestamp.valueOf(startDate));
            stmt.setTimestamp(3, Timestamp.valueOf(endDate));
            stmt.setString(4, parameters);
            stmt.setString(5, reportType);
            stmt.setString(6, String.valueOf(createDate));
            stmt.executeQuery();
        } catch (Exception e) {
            System.out.println("Error creating report : " + e.getMessage());
        }
    }

    /*Delete Report */
    public void deleteReport(int rid){
        String query = "DELETE FROM Reports WHERE rid = ?";
        try(PreparedStatement stmt = connection.prepareStatement(query)){
            stmt.setInt(1, rid);
            stmt.executeQuery();
        } catch (Exception e){
            System.out.println("Error deleting report : " + e.getMessage());
        }
    }

    /*Update report */

}
