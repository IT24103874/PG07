package com.X.CarRental.repo;

import com.X.CarRental.model.customer;
import com.X.CarRental.model.employee;
import com.X.CarRental.model.report;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Repository
public class usersRepo {
    private String url = "jdbc:sqlserver://localhost:1433;databaseName=xCarRental;encrypt=false";
    private String username = "sa";
    private String password = "Y2S1seProject";
    private Connection connection;

    public usersRepo(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            System.out.println("Driver loaded!");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver failed!" + e.getMessage());
        }

        try{
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection successful!");
        } catch (SQLException e) {
            System.out.println("Connection failed!" + e.getMessage());
        }
    }

    public ArrayList<customer> getCustomers() {
        ArrayList<customer> customers = new ArrayList<>();
        String query = "select * from customer";
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                customer customer = new customer(
                        rs.getString("nic"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("paymentInfo"),
                        rs.getString("password")
                );
                customers.add(customer);
            }
        } catch (SQLException e) {
            System.out.println("Error at getCustomer in usersRepo -> " + e.getMessage());
        }
        return customers;
    }

    public ArrayList<employee> getEmployees() {
        ArrayList<employee> employees = new ArrayList<>();
        String query = "select * from employee";
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                employee employee = new employee(
                        rs.getInt("eid"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("password"),
                        rs.getString("email"),
                        rs.getString("type")
                );
                employees.add(employee);
            }
        } catch (SQLException e) {
            System.out.println("Error at getEmployees in usersRepo -> " + e.getMessage());
        }
        return employees;
    }

    public void registerCustomer(customer customer){
        String query = "insert into customer values(?,?,?,?,?)";
        Map<String, String> jsonMap = new HashMap<>();
        jsonMap.put("accountNumber", customer.getAccount());
        jsonMap.put("bank", customer.getBank());
        jsonMap.put("branch", customer.getBranch());

// Convert map to JSON
        ObjectMapper mapper = new ObjectMapper();
        try{
            String json = mapper.writeValueAsString(jsonMap);
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, customer.getNic().trim());
            stmt.setString(2, (customer.getFirstname().trim() + " " + customer.getLastname().trim()));
            stmt.setString(3, customer.getPhone().trim());
            stmt.setString(4, json);
            stmt.setString(5, customer.getPassword().trim());
            stmt.executeUpdate();

        } catch (JsonProcessingException | SQLException e) {
            System.out.println("Error at registerCustomer in usersRepo -> " + e.getMessage());
        }
    }

    public void deleteUser(String nic){
        String query = "delete from customer where nic = ?";
        try{
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, String.valueOf(nic));
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error at deleteUser in usersRepo -> " + e.getMessage());
        }
    }

    public void deleteEmployee(int eid){
        String query = "delete from employee where eid = ?";
        try{
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, String.valueOf(eid));
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error at deleteEmployee in usersRepo -> " + e.getMessage());
        }
    }

    public void updateCustomer(customer customer){
        String query = "update customer set name = ?, phone = ?, paymentInfo = ?, password = ? where nic = ?";
        Map<String, String> jsonMap = new HashMap<>();
        jsonMap.put("accountNumber", customer.getAccount());
        jsonMap.put("branch", customer.getBranch());
        jsonMap.put("bank", customer.getBank());

        customer.printDetails();

// Convert map to JSON
        ObjectMapper mapper = new ObjectMapper();
        try{
            String json = mapper.writeValueAsString(jsonMap);
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, customer.getFirstname() + " " + customer.getLastname());
            stmt.setString(2, customer.getPhone());
            stmt.setString(3, json);
            stmt.setString(4, customer.getPassword());
            stmt.setString(5, customer.getNic());
            stmt.executeUpdate();

        } catch (JsonProcessingException | SQLException e) {
            System.out.println("Error at updateCustomer in usersRepo -> " + e.getMessage());
        }
    }

    public void createEmployee(employee employee){
        String query = "insert into employee(name, phone, type, password, email) values(?,?,?,?,?)";
        try{
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, (employee.getFirstname() + " " + employee.getLastname()).trim());
            stmt.setString(2, employee.getPhone());
            stmt.setString(3, employee.getType());
            stmt.setString(4, employee.getPassword());
            stmt.setString(5, employee.getEmail());
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error at createEmployee in usersRepo -> " + e.getMessage());
        }
    }

    public void updateEmployee(employee employee){
        String query = "update employee set name = ?, phone = ?, password = ?, email = ? where eid = ?";
        try{
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, employee.getFirstname() + " " + employee.getLastname());
            stmt.setString(2, employee.getPhone());
            stmt.setString(3, employee.getPassword());
            stmt.setString(4, employee.getEmail());
            stmt.setString(5, String.valueOf(employee.getEid()));
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error at updateEmployee in usersRepo -> " + e.getMessage());
        }
    }

    public employee getEmployee(int eid){
        ArrayList<employee> employees = getEmployees();
        for (employee employee : employees) {
            if (employee.getEid() == eid) {
                return employee;
            }
        }
        return null;
    }
}
