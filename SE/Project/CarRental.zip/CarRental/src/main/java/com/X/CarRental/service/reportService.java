package com.X.CarRental.service;

import com.X.CarRental.model.report;
import com.X.CarRental.repo.reportsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class reportService {
    reportsRepo reportsRepo;

    @Autowired
    public reportService(reportsRepo reportsRepo) {
        this.reportsRepo = reportsRepo;
    }

    public ArrayList<report> loadViewReport() {
        ArrayList<report> reports;
        reportsRepo.redoReports();
        reports = reportsRepo.getReports();
        return reports;
    }

    public List<Map<String, Object>> getAllBookings(int rid) {
        List<Map<String, Object>> bookings = new ArrayList<>();
        report report = reportsRepo.getReport(rid);
        LocalDateTime startDate = report.getStartTime();
        LocalDateTime endDate = report.getEndTime();
        try {
            bookings = reportsRepo.getBetweenDatesBookings(startDate,endDate);
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }
        return bookings;
    }

    public void createReport(report report) {
        reportsRepo.createReport(report.getName(), report.getStartTime(), report.getEndTime(), report.getParameters().toString().replace("[", "").replace("]", ""), report.getType(), report.getDate());
    }

    public void deleteReport(int rid) {
        reportsRepo.deleteReport(rid);
    }



    public ArrayList<report> filterReport(ArrayList<report> reports, String filter) {
        ArrayList<report> filteredReports = new ArrayList<>();
        for (report report : reports) {
            if (report.getName().toLowerCase().contains(filter.toLowerCase())) {
                filteredReports.add(report);
            }
        }
        return filteredReports;
    }
}
