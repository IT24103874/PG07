package com.X.CarRental.model;

import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

@Setter
@Getter
public class report {
    public int rid;
    private String name;
    private LocalDate date;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private ArrayList<String> parameters;
    private ArrayList<String> parametersAnswers;
    private String type;

    public report(int rid, String name, LocalDate date, Timestamp startTime, Timestamp endTime, ArrayList<String> parameters, ArrayList<String> setParametersAnswers, String type) {
        this.rid = rid;
        this.name = name;
        this.date = date;
        this.startTime = startTime.toLocalDateTime();
        this.endTime = endTime.toLocalDateTime();
        this.parameters = parameters;
        this.parametersAnswers = setParametersAnswers;
        cleanUpAnswers();
        this.type = type;
    }

    public void cleanUpAnswers(){
        for (int i = 0; i < parametersAnswers.size(); i++){
            String cleaned = parametersAnswers.get(i).replace("[", "").replace("]", "");
            this.parametersAnswers.set(i, cleaned);
        }
    }
}
